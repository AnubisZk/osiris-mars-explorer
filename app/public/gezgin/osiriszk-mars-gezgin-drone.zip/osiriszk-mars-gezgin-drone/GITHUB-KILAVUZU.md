# GitHub'a yükleme ve oyunu yayına alma kılavuzu

**Türkçe** · [English summary](#english)

Bu kılavuz `osiriszk-mars-gezgin-drone.zip` dosyasını ilk kez GitHub'a yüklemek ve oyunu internette
herkesin açabileceği bir adrese koymak içindir. Hesaplar (GitHub, Netlify) **öğretmenindir**; öğrenciler
öğretmenin gözetiminde çalışır.

> ⏱ Süre: yaklaşık 15 dakika · 🔐 Depoya hiçbir şifre, anahtar ya da kişisel bilgi konmaz.

---

## 1. Zip'i açın
1. `osiriszk-mars-gezgin-drone.zip` dosyasına sağ tıklayın → **Tümünü ayıkla**.
2. Açılan `osiriszk-mars-gezgin-drone` klasörünün içinde şunları görmelisiniz:
   `index.html`, `README.md`, `GITHUB-KILAVUZU.md`, `netlify.toml`, `.gitignore`, `.github`,
   `oyun`, `web`, `modeller`, `belgeler`.
3. Mac kullanıyorsanız `.github` ve `.gitignore` gizli görünür. Görmek için Finder'da
   **Cmd + Shift + .** tuşlarına basın.

> ⚠ GitHub zip dosyasını **açmaz**. Zip'in kendisini değil, **klasörün içindekileri** yükleyeceğiz.

## 2. Boş depoyu oluşturun
1. <https://github.com/new> adresine gidin (öğretmen hesabıyla, ör. `AnubisZk`).
2. **Repository name:** `osiriszk-mars-gezgin-drone`
   (Başka bir ad seçerseniz `index.html`'in altındaki "kaynak kodu" bağlantısını da düzeltin.)
3. **Description:** `OsirisZk Mars Pathfinder — Ingenuity benzeri drone + gezgin keşif oyunu (TR/EN)`
4. **Public** seçin (Netlify ve GitHub Pages ücretsiz yayın için).
5. **Add a README file**, **.gitignore**, **license** kutularını **işaretlemeyin** (bunlar zip'te var).
6. **Create repository**'ye basın.

## 3. Dosyaları yükleyin

### Yol A — Tarayıcıdan (en kolay)
1. Yeni deponun sayfasında **"uploading an existing file"** bağlantısına tıklayın.
2. Bilgisayarınızda `osiriszk-mars-gezgin-drone` klasörünü açın, içindeki **her şeyi seçin**
   (Ctrl + A / Cmd + A) ve tarayıcıdaki kutuya **sürükleyip bırakın**. Klasörler alt klasörleriyle gelir.
3. Listede `.github/workflows/testler.yml` ve `netlify.toml` dosyalarının da olduğunu kontrol edin.
4. **Commit changes** kutusuna şunu yazın: `İlk sürüm: OsirisZk Mars Pathfinder v3.2 (masaüstü + web, TR/EN)`
5. **Commit changes**'e basın.

> `.github` klasörü sürüklenmediyse: depoda **Add file → Create new file** deyin, ad olarak
> `.github/workflows/testler.yml` yazın ve zip'teki aynı dosyanın içeriğini yapıştırın.

### Yol B — GitHub Desktop
1. GitHub Desktop → **File → Clone repository** → `osiriszk-mars-gezgin-drone`.
2. Zip'teki klasörün içindekileri, klonlanan klasöre kopyalayın.
3. Özet: `İlk sürüm: OsirisZk Mars Pathfinder v3.2` → **Commit to main** → **Push origin**.

### Yol C — Komut satırı
```bash
cd osiriszk-mars-gezgin-drone
git init -b main
git add .
git commit -m "İlk sürüm: OsirisZk Mars Pathfinder v3.2 (masaüstü + web, TR/EN)"
git remote add origin https://github.com/AnubisZk/osiriszk-mars-gezgin-drone.git
git push -u origin main
```

## 4. Testlerin yeşil olduğunu görün
Depoda **Actions** sekmesine gidin. "Testler" iş akışı birkaç dakika içinde ✅ olmalı.
Bu iş akışı her yüklemede masaüstü testlerini, araç modeli uyumunu ve web köprüsünü (İngilizce çeviriler
dahil) denetler. ❌ görürseniz kırmızı satıra tıklayıp hata mesajını okuyun.

## 5. Oyunu yayına alın

### Seçenek 1 — Netlify (önerilen; OsirisZk sitesiyle aynı yer)
1. <https://app.netlify.com> → **Add new project → Import an existing project → GitHub**.
2. `osiriszk-mars-gezgin-drone` deposunu seçin.
3. Ayarlar `netlify.toml`'dan otomatik gelir: **Build command boş**, **Publish directory `.`**.
4. **Deploy**'a basın. 1 dakika içinde `https://<rastgele-ad>.netlify.app` adresinde açılır.
5. **Project configuration → Change project name** → `osiriszk-mars-gezgin` yazın.
   Adres: `https://osiriszk-mars-gezgin.netlify.app`
6. Bundan sonra GitHub'a yapılan her yükleme siteyi **kendiliğinden** günceller.

### Seçenek 2 — GitHub Pages (Netlify'sız)
1. Depoda **Settings → Pages**.
2. **Source: Deploy from a branch**, **Branch: `main`**, klasör **`/ (root)`** → **Save**.
3. Birkaç dakika sonra adres: `https://anubiszk.github.io/osiriszk-mars-gezgin-drone/`

İki seçenekte de derleme yoktur: oyun dosyaları olduğu gibi yayımlanır. Oyun motoru (Python), ilk açılışta
tarayıcıya yaklaşık 15 MB olarak `cdn.jsdelivr.net` adresinden yüklenir; okul ağı bu adresi engelliyorsa
masaüstü sürümünü kullanın.

### Yayını kontrol edin
- Sayfa açılınca "Oyun motoru yükleniyor" yazısı kaybolmalı.
- **Başlat**'a basın, **Space** ile kalkın, **WASD** ile uçun.
- Sağ üstteki **TR / EN** düğmesiyle dili değiştirin; `?dil=en` ile İngilizce bağlantı paylaşabilirsiniz.
- `…/modeller/` sayfasında araç çizimleri ve değerleri görünmeli.

## 6. Öğrencilerle çalışma kuralları
- **Ana dal (`main`) korunsun:** Settings → Branches → **Add branch ruleset** → `main` için
  "Require a pull request before merging" ve "Block force pushes" açın. Böylece kimsenin çalışması
  üzerine yazılamaz ya da silinemez.
- Her öğrenci ya da takım kendi dalında çalışır (`ogrenci/drone-fizigi` gibi), bitince **Pull request** açar,
  öğretmen inceleyip birleştirir.
- Bir değeri değiştirmek isteyen önce `modeller/modeller.json`'u, sonra `oyun/mars_core.py`'yi günceller;
  `test_modeller.py` ikisinin uyumunu denetler.
- Yeni bir oyun mesajı eklenirse `web/ceviri.py`'ye İngilizcesi de eklenir (yoksa test kırmızı olur).
- Depoya **şifre, API anahtarı, ad soyad, okul numarası, fotoğraf** konmaz.
- Lisans: Depoyu başkalarının nasıl kullanabileceğine öğretmen karar verir; karar verilince GitHub'da
  **Add file → Create new file → `LICENSE`** ile şablon seçilebilir.

## 7. Sorun giderme
| Belirti | Çözüm |
|---|---|
| Netlify sayfası "Page not found" | Publish directory `.` mı? `index.html` deponun **kökünde** mi (bir klasörün içinde değil)? |
| "Oyun motoru yüklenemedi" | İnternet bağlantısı ya da okul ağı `cdn.jsdelivr.net`'i engelliyor olabilir; masaüstü sürümünü kullanın. |
| Actions'ta test ❌ | Hata satırını okuyun; çoğunlukla `modeller.json` ile `mars_core.py` farklı değerdedir. |
| Masaüstü sürümü açılmıyor | Python 3.10+ ve tkinter gerekir (Windows Python kurulumunda vardır). `oyun/README.txt`'ye bakın. |
| Yüklemede bazı dosyalar eksik | Tarayıcıdan yüklemede en çok 100 dosya bir kerede yüklenir; eksikleri ikinci kez sürükleyin. |

---

<a id="english"></a>
## English summary

1. **Unzip** `osiriszk-mars-gezgin-drone.zip`. GitHub does not unpack zip files, so you upload the
   *contents* of the folder (including the hidden `.github` folder and `.gitignore`).
2. **Create an empty public repository** at <https://github.com/new> named `osiriszk-mars-gezgin-drone`.
   Do not add a README, .gitignore or license (they are in the zip).
3. **Upload:** click *uploading an existing file*, drag everything from the folder, commit with
   `Initial release: OsirisZk Mars Pathfinder v3.2 (desktop + web, TR/EN)`. Alternatives: GitHub Desktop
   or `git init -b main && git add . && git commit -m "…" && git remote add origin … && git push -u origin main`.
4. **Check the tests:** the *Actions* tab should show the "Testler" workflow passing ✅.
5. **Go live:** Netlify → *Add new project → Import from GitHub* → choose the repo; settings come from
   `netlify.toml` (no build, publish `.`) → *Deploy*, then rename the project to `osiriszk-mars-gezgin`.
   Or use GitHub Pages: *Settings → Pages → Deploy from branch `main` / root*.
6. **Verify:** the loading message disappears, *Start* + Space takes off, the **TR / EN** switch changes the
   language (`?dil=en` links straight to English), and `/modeller/` shows the vehicle drawings.
7. **Working with students:** protect `main` (require pull requests, block force pushes), one branch per
   student/team, no passwords, keys or personal data in the repository. When a new game message is added,
   add its English translation to `web/ceviri.py` (the tests enforce this).
